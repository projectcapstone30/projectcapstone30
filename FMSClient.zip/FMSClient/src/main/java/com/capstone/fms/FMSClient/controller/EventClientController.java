package com.capstone.fms.FMSClient.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.capstone.fms.FMSClient.domain.Event;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class EventClientController {
	WebClient webClient = WebClient.create("http://localhost:8085");

	@GetMapping("/client/retrieveEvents")
	public Flux<Event> getEventsByUsingRetrieve() {
		return webClient.get().uri("/getEvents").retrieve().bodyToFlux(Event.class)
				.log("get all events in client project");
	}

	@GetMapping("/client/retrieve/eventById")
	public Flux<Event> getSpecificEventByUsingRetrieve() {
		String eventId = "EVNT00047261";
		return webClient.get().uri("/getEvents/{eventId}", eventId).retrieve().bodyToFlux(Event.class)
				.log("get specific event in client project");
	}

	@GetMapping("/client/sendMail")
	public Mono<String> sendMail() {
		return webClient.get().uri("/sendEmail").retrieve().bodyToMono(String.class);
	}

}
