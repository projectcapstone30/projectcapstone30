package com.cts.capstrone.FeedbackManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.capstrone.FeedbackManagementSystem.model.Event;
import com.cts.capstrone.FeedbackManagementSystem.repository.EventRepo;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EventRepoImpl {
	@Autowired
	public EventRepo eventRepo;
	
	public Flux<Event> getAllEvents(){
		return eventRepo.findAll();
	}
	public Mono<Event> getEventDetailsById(Integer id){
		return eventRepo.findById(id);
	}
	
	public Mono<Event> saveEvents(Event e) {
		return eventRepo.save(e);
	}
	
	public Mono<Void> deleteEvent(int eventId) {
		return eventRepo.deleteById(eventId);
	}
	
	public Mono<Void> deleteAllEvents() {
		return eventRepo.deleteAll();
	}
	
	
}
