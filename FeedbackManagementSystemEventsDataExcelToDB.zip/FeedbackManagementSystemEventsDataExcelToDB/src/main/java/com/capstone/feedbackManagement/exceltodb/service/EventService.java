package com.capstone.feedbackManagement.exceltodb.service;

import com.capstone.feedbackManagement.exceltodb.domain.Events;
import com.capstone.feedbackManagement.exceltodb.repository.EventRepository;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class EventService {
	
	@Autowired
    private EventRepository eventRepository;
	
    public List<Events> save(MultipartFile excelDataFile) throws IOException {
    	
    	List<Events> tempEventsList = new ArrayList<Events>();
        XSSFWorkbook workbook = new XSSFWorkbook(excelDataFile.getInputStream());
        XSSFSheet worksheet = workbook.getSheetAt(0);
        Events event = null;
        Events tempEvents = new Events();
        for(int i=1;i<worksheet.getPhysicalNumberOfRows() ;i++) {

            XSSFRow row = worksheet.getRow(i);

            tempEvents.setId((int) row.getCell(0).getNumericCellValue());
            tempEvents.setEvent_id(row.getCell(1).getStringCellValue());
            tempEvents.setBase_location(row.getCell(2).getStringCellValue());
            tempEvents.setBeneficiary_name(row.getCell(3).getStringCellValue());
            tempEvents.setCouncil_name(row.getCell(4).getStringCellValue());
            tempEvents.setEvent_name(row.getCell(5).getStringCellValue());
            tempEvents.setEvent_description(row.getCell(6).getStringCellValue());
            tempEvents.setEvent_date(row.getCell(7).getDateCellValue());
            tempEvents.setEmployee_id(row.getCell(8).getStringCellValue());
            tempEvents.setEmployee_name(row.getCell(9).getStringCellValue());
            tempEvents.setVolunteer_hours((int) row.getCell(10).getNumericCellValue());
            tempEvents.setTravel_hours((int) row.getCell(11).getNumericCellValue());
            tempEvents.setLives_impacted((int) row.getCell(12).getNumericCellValue());
            tempEvents.setBusiness_unit(row.getCell(13).getStringCellValue());
            tempEvents.setEvent_status(row.getCell(14).getStringCellValue());
            tempEvents.setIiep_category(row.getCell(15).getStringCellValue()); 
            event = eventRepository.save(tempEvents);
            System.out.println(event.toString());
            tempEventsList.add(event);
        }
		return tempEventsList;
    }

}
