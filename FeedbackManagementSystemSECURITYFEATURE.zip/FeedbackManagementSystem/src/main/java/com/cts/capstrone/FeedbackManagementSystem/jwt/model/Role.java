package com.cts.capstrone.FeedbackManagementSystem.jwt.model;

public enum Role {
	ROLE_PMO, ROLE_ADMIN,ROLE_POC, ROLE_USER
}
