package com.cts.capstrone.FeedbackManagementSystem.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

import com.cts.capstrone.FeedbackManagementSystem.model.Event;

import reactor.core.publisher.Flux;
@Repository
public interface EventRepo extends ReactiveMongoRepository<Event, Integer> {
	
}
