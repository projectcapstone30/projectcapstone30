package com.capstone.feedbackManagement.exceltodb.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capstone.feedbackManagement.exceltodb.domain.Events;
import com.capstone.feedbackManagement.exceltodb.service.EventService;

@RestController
public class EventController {
	
	@Autowired
    private EventService eventService;

   
    @PostMapping("/uploadEvents")
    public List<Events> mapEventsDataExceltoDB(@RequestParam("file") MultipartFile excelDataFile) throws IOException {

       return eventService.save(excelDataFile);
    }

}
