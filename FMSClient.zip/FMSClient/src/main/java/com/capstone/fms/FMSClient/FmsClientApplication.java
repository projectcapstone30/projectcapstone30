package com.capstone.fms.FMSClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FmsClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(FmsClientApplication.class, args);
	}

}
