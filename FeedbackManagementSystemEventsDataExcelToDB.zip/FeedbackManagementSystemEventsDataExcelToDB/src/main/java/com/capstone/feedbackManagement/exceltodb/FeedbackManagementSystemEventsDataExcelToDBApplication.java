package com.capstone.feedbackManagement.exceltodb;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackManagementSystemEventsDataExcelToDBApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsDataExcelToDBApplication.class, args);
	}
	
}
