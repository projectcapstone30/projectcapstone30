package com.capstone.feedbackManagement.exceltodb.repository;

import org.springframework.data.repository.CrudRepository;

import com.capstone.feedbackManagement.exceltodb.domain.Events;

public interface EventRepository extends CrudRepository<Events, Integer> {



}
