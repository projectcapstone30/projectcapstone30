INSERT INTO Event (eventId, eventName, eventDate,businessUnit,venue,totalVollunteers,vallunteerHours,travelHours) VALUES

  (1,'Skin Cancer On Holi','11-03-2020','HealthCare','Approved','DLF',5,8,7);