
import React, { Component } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import Question from './Feedback/Question';
import AddQuestion from './Feedback/AddQuestion';
import EditQuestion from './Feedback/EditQuestion';
import ThanksScreen from './Feedback/ThanksScreen';



const Routing = props=>{
return (
<div>
    <Switch>
        <Route  path='/questioninfo' component={Question}/>
        <Route path='/addquestion' component={AddQuestion} />
        <Route path='/editquestion' component={EditQuestion} />
        <Route path='/thanksscreen' component={ThanksScreen} />

    </Switch>
    </div>
    )
}

export default Routing;