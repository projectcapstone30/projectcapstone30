package com.capstone.fms.FMSClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FmsClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
