package com.cts.capstrone.FeedbackManagementSystem.configuration;

public class BeanConfig {

}
